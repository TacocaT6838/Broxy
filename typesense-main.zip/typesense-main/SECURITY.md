Please report any security vulnerabilities to security@typesense.org. 
