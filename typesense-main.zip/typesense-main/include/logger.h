#pragma once

#include <glog/logging.h>